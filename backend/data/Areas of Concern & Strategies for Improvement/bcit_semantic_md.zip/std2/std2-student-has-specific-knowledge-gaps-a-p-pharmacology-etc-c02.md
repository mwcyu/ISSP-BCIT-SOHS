---
doc_id: std2-student-has-specific-knowledge-gaps-a-p-pharmacology-etc-c02
title: STANDARD 2: Knowledge-Based Practice — Student has specific knowledge gaps (A&P, pharmacology etc.) (Chunk 2)
standard: 2
topic: student-has-specific-knowledge-gaps-a-p-pharmacology-etc
type: concern_strategies
source: bcit/practice-areas
version: 2025-10-16
path_hint: std2/std2-student-has-specific-knowledge-gaps-a-p-pharmacology-etc-c02.md
---
# STANDARD 2: Knowledge-Based Practice

## Concern
Student has specific knowledge gaps (A&P, pharmacology etc.)

## Strategies & Guidance
________________________________________
