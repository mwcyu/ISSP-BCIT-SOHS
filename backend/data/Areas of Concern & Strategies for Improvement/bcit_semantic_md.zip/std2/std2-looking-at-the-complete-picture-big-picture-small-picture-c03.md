---
doc_id: std2-looking-at-the-complete-picture-big-picture-small-picture-c03
title: STANDARD 2: Knowledge-Based Practice — Looking at the complete picture- (big picture, small picture, individualized picture) (Chunk 3)
standard: 2
topic: looking-at-the-complete-picture-big-picture-small-picture
type: concern_strategies
source: bcit/practice-areas
version: 2025-10-16
path_hint: std2/std2-looking-at-the-complete-picture-big-picture-small-picture-c03.md
---
# STANDARD 2: Knowledge-Based Practice

## Concern
Looking at the complete picture- (big picture, small picture, individualized picture)

## Strategies & Guidance
- Use a CJM and review clinical reasoning case studies. Ask yourself 'why' regarding each aspect of your patients care, run through scenarios and think about what you would do - ask a peer what they would do
________________________________________
________________________________________
