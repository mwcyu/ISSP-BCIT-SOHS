---
doc_id: std1-student-did-not-recognize-and-or-report-abnormal-patient-dat-c01
title: STANDARD 1: Professional Responsibility and Accountability — Student did not recognize and/or report abnormal patient data (Chunk 1)
standard: 1
topic: student-did-not-recognize-and-or-report-abnormal-patient-dat
type: concern_strategies
source: bcit/practice-areas
version: 2025-10-16
path_hint: std1/std1-student-did-not-recognize-and-or-report-abnormal-patient-dat-c01.md
---
# STANDARD 1: Professional Responsibility and Accountability

## Concern
Student did not recognize and/or report abnormal patient data

## Strategies & Guidance
Immediately halt unsupervised patient care until student has demonstrated safe practice consistently while supervised. Review BCCNM Regulatory Supervision of Students.
- Refer to BCIT BSN Program Student Guidelines and Procedures
- Have student fill out hospital authority incident report if required and BSN Safety Event form
Strategies:
- Suggest student review the British Columbia College of Nurses & Midwives (BCCNM) Professional Standards
- Suggest student review the BCCNM Professional Responsibility & Accountability Module
- 1:1 meeting with student, preceptor and instructor to discuss the situation - ensure the student shares their point of view and rationale
- Develop a plan with the student e.g. the student must be supervised with care until deemed safe, must report all assessment findings to preceptor
________________________________________
